function resetFunction() {
    document.getElementById("regis").reset();
}